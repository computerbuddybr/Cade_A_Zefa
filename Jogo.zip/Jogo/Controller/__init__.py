"""
Estas classes que controlam o fluxo do jogo
"""
