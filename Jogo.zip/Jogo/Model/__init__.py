"""
Estas classes que lidam com os Dados
"""
