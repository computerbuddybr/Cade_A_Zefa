"""
Estas classes que lidam com a visualização do Jogo na interface Tkinter de computador.
"""
