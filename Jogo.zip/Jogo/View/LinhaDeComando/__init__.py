"""
Esta classe lida com a visualização na Linha de Comando.
"""
