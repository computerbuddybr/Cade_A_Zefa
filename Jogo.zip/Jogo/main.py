from View.Computador.Computador import Computador
from View.Display7.Display7 import Display7
from View.LinhaDeComando.JogoLC import JogoLC

# Inicializando o Game desejado. Para tanto é só descomentar o desejado, e comentar os outros
computador = Computador()
# display7 = Display7()
# linhaDeComando = JogoLC()
