"""
Classes que controlam o fluxo do jogo
"""
