"""
Classes que lidam com os Dados
"""
