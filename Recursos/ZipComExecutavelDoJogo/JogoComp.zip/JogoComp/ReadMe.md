# Cadê a Zefa Gente!
## Jogo educacional

### Informações
- **Autora:** Adriana Laura Cerdeira
- **Projeto Final de Conclusão de Curso em Enegenharia de Computação - Universidade Anhembi Morumbi**
- **Outros integrantes do grupo:** Andre de Almeida Alves Batista, Gabriel Campos de Paula, Janderson Barbosa Braz, Thiago Henrique da Cruz

## Configurações do Projeto

- Linguagem: Python 3.12.0
- Dependências:
  - Haversine 2.8.0:
    - ```pip install haversine``` 
    - [Link Pypi](https://pypi.org/project/haversine/) e [Documentação](https://github.com/mapado/haversine) 
