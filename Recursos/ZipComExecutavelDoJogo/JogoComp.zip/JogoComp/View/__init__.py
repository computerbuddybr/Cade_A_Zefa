"""
Classes que lidam com a Visualização.
"""
