from View.Computador.Computador import Computador



# Inicializando o Game desejado. Para tanto é só descomentar o desejado, e comentar os outros
computador = Computador()

